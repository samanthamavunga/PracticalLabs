<!---THis file will contain database connection parameters-->

<?php
//servername is localhost
define("servername", "localhost");

//define username
define("username", "root");

//define password
define("password", "");

//define database name
define("dbname", "lab_post");
?>